# Surya-Inspired Gallery

A minimal photo gallery inspired by mountain landscapes and wanderlust, built using HTML and CSS.

## 🌄 Live Preview

> Coming soon via GitHub Pages...

## 🚀 How to Use

1. Clone the repo or upload to GitHub.
2. Go to **Settings → Pages**.
3. Select the `main` branch and root (`/`) folder.
4. Save and wait a few seconds — you'll get a public URL like:
   https://yourusername.github.io/surya-gallery/

## 💡 Features

- Responsive photo grid
- Glowing text effects
- Smooth image hover transitions
- Malayalam/Tamil bilingual description section

## 📸 Credits

All images belong to Surya (or used for demonstration). Replace them with your own for customization.
